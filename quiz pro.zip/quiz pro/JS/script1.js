let timeLeft = document.querySelector(".time-left");
let quizContainer = document.getElementById("container");
let nextBtn = document.getElementById("next-button");
let countOfQuestion = document.querySelector(".number-of-question");
let displayContainer = document.getElementById("display-container");
let scoreContainer = document.querySelector(".score-container");
let restart = document.getElementById("restart");
let userScore = document.getElementById("user-score");
let startScreen = document.querySelector(".start-screen");
let startButton = document.getElementById("start-button");
let questionCount;
let scoreCount = 0;
let count = 11;
let countdown;

//Questions and Options array

const quizArray = [
    {
        id: "0",
        question: "What is the world's tallest freestanding structure?",
        options:["Eiffel Tower","Burj Kalifa","Statue of Liberty","Sydney Opera House"],
        correct: "Burj Kalifa",
    },
    {
        id: "1",
        question: " Which ancient wonder of the world is still partly standing in Egypt?",
        options: [" Colosseum", "The Great Wall Of China", " Hanging Gardens of Babylon", " Pyramids of Giza"],
        correct: " Pyramids of Giza",
    },
    {
        id: "2",
        question: "In which city can you find the Christ the Redeemer statue, one of the New Seven Wonders of the World?",
        options: ["Rio de Janeiro", "Mexico City", "Buenos Aires", "Cape Town"],
        correct: "Rio de Janeiro",
    },
    {
        id: "3",
        question: "Which famous structure, situated in New York Harbor, was a gift from France to the United States and is a symbol of freedom and democracy?",
        options: ["Statue of Liberty", "Golden Gate Bridge", "Hoover Dam", "Mount Rushmore"],
        correct: "Statue of Liberty",
    },
    {
        id: "4",
        question: "Which world-famous palace complex is located in the Indian city of Agra and is known for its stunning white marble architecture?",
        options: ["Buckingham Palace", "Versailles Palace", "Forbidden City", " Taj Mahal"],
        correct: " Taj Mahall",
    },
    {
        id: "5",
        question: "What is the capital city of Australia?",
        options: [" Sydney", " Melbourne", "Canberra", "Brisbane"],
        correct: "Canberra",
    }, {
        id: "6",
        question: "In which African country can you find the Sphinx and the Great Pyramid of Giza?",
        options: ["Egypt", "Morocco", "Kenya", "South Africa"],
        correct: "Egypt",
    },
    {
        id: "7",
        question: "What is the famous wall built to protect against invasions by nomadic tribes in ancient China?What is the famous wall built to protect against invasions by nomadic tribes in ancient China?",
        options: [" Hadrian's Wall", "Berlin Wall", " Great Wall of China", "Antonine Wall"],
        correct: "Great Wall of China",
    },
    {
        id: "8",
        question: "In which city would you find the famous Sydney Opera House?",
        options: ["Melbourne", "Sydney", "Brisbane", " Perth"],
        correct: "Sydney",
    },
    {
        id: "9",
        question: "The Great Sphinx of Giza has the body of a lion and the head of which mythical creature?",
        options: [" Griffin", "Harpy", "Sphinx", "Minotaur"],
        correct: "Sphinx",
    },
];

//Restart Quiz
restart.addEventListener("click", () => {
    initial();
    displayContainer.classList.remove("hide");
    scoreContainer.classList.add("hide");
});

//Next Button
nextBtn.addEventListener(
    "click",
    (displayNext = () => {
        //increment questionCount
        questionCount += 1;
        //if last question
        if (questionCount == quizArray.length) {
            //hide question container and display score
            displayContainer.classList.add("hide");
            scoreContainer.classList.remove("hide");
            //user score
            userScore.innerHTML =
                "Your score is " + scoreCount + " out of " + questionCount;
        } else {
            //display questionCount
            countOfQuestion.innerHTML =
                questionCount + 1 + " of " + quizArray.length + " Question";
            //display quiz
            quizDisplay(questionCount);
            count = 11;
            clearInterval(countdown);
            timerDisplay();
        }
    })
);

//Timer
const timerDisplay = () => {
    countdown = setInterval(() => {
        count--;
        timeLeft.innerHTML = `${count}s`;
        if (count == 0) {
            clearInterval(countdown);
            displayNext();
        }
    }, 1000);
};

//Display quiz
const quizDisplay = (questionCount) => {
    let quizCards = document.querySelectorAll(".container-mid");
    //Hide other cards
    quizCards.forEach((card) => {
        card.classList.add("hide");
    });
    //display current question card
    quizCards[questionCount].classList.remove("hide");
};

//Quiz Creation
function quizCreator() {
    //randomly sort questions
    quizArray.sort(() => Math.random() - 0.5);
    //generate quiz
    for (let i of quizArray) {
        //randomly sort options
        i.options.sort(() => Math.random() - 0.5);
        //quiz card creation
        let div = document.createElement("div");
        div.classList.add("container-mid", "hide");
        //question number
        countOfQuestion.innerHTML = 1 + " of " + quizArray.length + " Question";
        //question
        let question_DIV = document.createElement("p");
        question_DIV.classList.add("question");
        question_DIV.innerHTML = i.question;
        div.appendChild(question_DIV);
        //options
        div.innerHTML += `
    <button class="option-div" onclick="checker(this)">${i.options[0]}</button>
     <button class="option-div" onclick="checker(this)">${i.options[1]}</button>
      <button class="option-div" onclick="checker(this)">${i.options[2]}</button>
       <button class="option-div" onclick="checker(this)">${i.options[3]}</button>
    `;
        quizContainer.appendChild(div);
    }
}

//Checker Function to check if option is correct or not
function checker(userOption) {
    let userSolution = userOption.innerText;
    let question =
        document.getElementsByClassName("container-mid")[questionCount];
    let options = question.querySelectorAll(".option-div");

    //if user clicked answer == correct option stored in object
    if (userSolution === quizArray[questionCount].correct) {
        userOption.classList.add("correct");
        scoreCount++;
    } else {
        userOption.classList.add("incorrect");
        //For marking the correct option
        options.forEach((element) => {
            if (element.innerText == quizArray[questionCount].correct) {
                element.classList.add("correct");
            }
        });
    }

    //clear interval(stop timer)
    clearInterval(countdown);
    //disable all options
    options.forEach((element) => {
        element.disabled = true;
    });
}

//initial setup
function initial() {
    quizContainer.innerHTML = "";
    questionCount = 0;
    scoreCount = 0;
    count = 11;
    clearInterval(countdown);
    timerDisplay();
    quizCreator();
    quizDisplay(questionCount);
}

//when user click on start button
startButton.addEventListener("click", () => {
    startScreen.classList.add("hide");
    displayContainer.classList.remove("hide");
    initial();
});

//hide quiz and display start screen
window.onload = () => {
    startScreen.classList.remove("hide");
    displayContainer.classList.add("hide");
};